// Jika ada kesalahan tak terduga, tampilkan di layar supaya kelihatan penyebabnya (terutama di HP).
window.addEventListener("error", (e) => showError(e.message + (e.lineno ? " (baris " + e.lineno + ")" : "")));
window.addEventListener("unhandledrejection", (e) => showError(e.reason));

const QUOTES = [
  { text: "Mulailah dari mana kamu berada, gunakan apa yang kamu punya.", author: "Arthur Ashe" },
  { text: "Langkah kecil setiap hari lebih baik daripada lompatan besar sesekali.", author: "Anonim" },
  { text: "Fokus pada kemajuan, bukan kesempurnaan.", author: "Anonim" },
  { text: "Kerjakan yang penting dulu, sisanya menyusul.", author: "Anonim" },
  { text: "Konsistensi mengalahkan intensitas.", author: "Anonim" },
];

const GRADIENTS = [
  { nama: "Biru laut", warna: ["#1e3c72", "#2a5298"] },
  { nama: "Hijau teduh", warna: ["#134e5e", "#71b280"] },
  { nama: "Ungu senja", warna: ["#42275a", "#734b6d"] },
  { nama: "Abu arang", warna: ["#232526", "#414345"] },
  { nama: "Biru malam", warna: ["#0f2027", "#2c5364"] },
];

const DEFAULT_VIEW_HTML = '<!doctype html><meta charset="utf-8"><body style="margin:0;height:100vh;display:grid;place-items:center;background:#0f172a;color:#fff;font-family:system-ui"><h1 style="font-weight:300;font-size:64px">Hallo</h1>';
let views = []; // tampilan buatan sendiri: [{ id, nama, html }]

// Simpan daftar menu, lalu baca ulang untuk memastikan benar-benar tersimpan; salinan cadangan di localStorage.
async function saveViews() {
  try { localStorage.setItem("views-backup", JSON.stringify(views)); } catch (e) {}
  try {
    await store.set("views", views);
    const cek = await store.get("views", null);
    if (!Array.isArray(cek) || cek.length !== views.length) throw new Error("data tidak terbaca ulang");
    status("Tersimpan (" + views.length + " menu buatan).");
    return true;
  } catch (e) {
    status("Gagal menyimpan: " + (e && e.message ? e.message : e), true);
    return false;
  }
}
function status(t, err) {
  const el = $("menu-status");
  if (!el) return;
  el.textContent = t;
  el.style.color = err ? "#fca5a5" : "";
}

const DEFAULT_SETTINGS = { nama: "", jam24: true, latar: "harian", warna: 0, gambar: "", foto: "hari", tampilan: "board" };

// Tampilan Start dimuat di iframe agar alamat tab tetap newtab.html (kolom alamat Chrome tetap kosong)
window.addEventListener("message", (e) => {
  if (e.origin === location.origin && e.data && e.data.aistim === "board") location.reload();
});

function showStart(page = "menu/icu.html") {
  const f = document.createElement("iframe");
  f.src = page;
  f.style.cssText = "position:fixed;inset:0;width:100%;height:100%;border:0";
  document.body.replaceChildren(f);
}

function openCustom() {
  const id = String(settings.tampilan).slice(2);
  if (views.some((v) => v.id === id)) return showStart("menu/sync.html?id=" + encodeURIComponent(id));
  settings.tampilan = "board"; // tampilan sudah dihapus: kembali ke Board
  store.set("settings", settings);
  applyBackground();
  tick();
}

const $ = (id) => document.getElementById(id);

// ---------- Penyimpanan (chrome.storage.local, cadangan localStorage saat dibuka sebagai file biasa) ----------
const hasChrome = typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;
const store = {
  async get(key, fallback) {
    if (hasChrome) {
      const r = await chrome.storage.local.get(key);
      return r[key] === undefined ? fallback : r[key];
    }
    try {
      const v = localStorage.getItem(key);
      return v === null ? fallback : JSON.parse(v);
    } catch (e) {
      return fallback;
    }
  },
  async set(key, value) {
    if (hasChrome) await chrome.storage.local.set({ [key]: value });
    else localStorage.setItem(key, JSON.stringify(value));
  },
};

let settings = { ...DEFAULT_SETTINGS };
let todos = [];

// ---------- Jam, tanggal, sapaan ----------
function greetingFor(hour) {
  if (hour < 11) return "Selamat pagi";
  if (hour < 15) return "Selamat siang";
  if (hour < 18) return "Selamat sore";
  return "Selamat malam";
}

function tick() {
  if (!$("clock")) return;
  const now = new Date();
  $("clock").textContent = now.toLocaleTimeString("id-ID", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: !settings.jam24,
  });
  $("date").textContent = now.toLocaleDateString("id-ID", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
  const nama = (settings.nama || "").trim();
  $("greeting").textContent = greetingFor(now.getHours()) + (nama ? ", " + nama : "");
}

// ---------- Kutipan & latar ----------
function dayIndex() {
  return Math.floor(Date.now() / 86400000);
}

function initQuote() {
  const q = QUOTES[dayIndex() % QUOTES.length];
  $("quote-text").textContent = `“${q.text}”`;
  $("quote-author").textContent = q.author;
}

const SEED_TAB = Math.random().toString(36).slice(2, 10); // tetap selama satu kali buka tab
function fotoUrl() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, "0");
  const hari = d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate());
  const seed = settings.foto === "tab" ? SEED_TAB : settings.foto === "jam" ? hari + "h" + p(d.getHours()) : hari;
  const r = window.devicePixelRatio || 1;
  const w = Math.min(2560, Math.max(640, Math.round((screen.width * r) / 160) * 160));
  const h = Math.min(1600, Math.max(480, Math.round((screen.height * r) / 160) * 160));
  return "https://picsum.photos/seed/" + seed + "/" + w + "/" + h;
}
function applyGradient() {
  const b = document.body.style;
  const idx = settings.latar === "warna" ? settings.warna : dayIndex();
  const [a, c] = GRADIENTS[((idx % GRADIENTS.length) + GRADIENTS.length) % GRADIENTS.length].warna;
  b.background = `linear-gradient(135deg, ${a}, ${c})`;
  b.backgroundAttachment = "fixed";
}
function fotoStatus(teks, ms) {
  let el = document.getElementById("foto-status");
  if (!teks) { if (el) el.remove(); return; }
  if (!el) {
    el = document.createElement("div");
    el.id = "foto-status";
    el.style.cssText = "position:fixed;left:12px;bottom:12px;padding:6px 10px;border-radius:999px;background:#000a;color:#fff;font:12px system-ui;z-index:50;max-width:calc(100% - 24px)";
    document.body.append(el);
  }
  el.textContent = teks;
  clearTimeout(fotoStatus.t);
  if (ms) fotoStatus.t = setTimeout(() => el.remove(), ms);
}
function applyBackground() {
  const b = document.body.style;
  fotoStatus("");
  if (settings.latar === "online") {
    applyGradient(); // sementara dan cadangan bila offline
    const url = fotoUrl();
    const img = new Image();
    let selesai = false;
    const lambat = setTimeout(() => { if (!selesai) fotoStatus("Foto online lambat dimuat, masih menunggu…"); }, 4000);
    img.onload = () => {
      selesai = true;
      clearTimeout(lambat);
      fotoStatus("");
      if (settings.latar !== "online") return;
      b.background = `linear-gradient(rgba(0,0,0,.35), rgba(0,0,0,.35)), center / cover no-repeat url("${url}")`;
      b.backgroundAttachment = "fixed";
    };
    img.onerror = () => {
      selesai = true;
      clearTimeout(lambat);
      fotoStatus("Foto online gagal dimuat (offline atau diblokir). Memakai gradien.", 8000);
    };
    img.src = url;
    return;
  }
  if (settings.latar === "gambar" && settings.gambar) {
    b.background = `center / cover no-repeat url("${settings.gambar}")`;
    b.backgroundAttachment = "fixed";
    return;
  }
  const idx = settings.latar === "warna" ? settings.warna : dayIndex();
  const [a, c] = GRADIENTS[((idx % GRADIENTS.length) + GRADIENTS.length) % GRADIENTS.length].warna;
  b.background = `linear-gradient(135deg, ${a}, ${c})`;
  b.backgroundAttachment = "fixed";
}

// ---------- Todo ----------
function msg(text) {
  const el = $("todo-msg");
  el.textContent = text;
  clearTimeout(msg.t);
  if (text) msg.t = setTimeout(() => (el.textContent = ""), 4000);
}

async function saveTodos() {
  await store.set("todos", todos);
}

function startEdit(li, i) {
  const span = li.querySelector("span");
  const input = document.createElement("input");
  input.type = "text";
  input.className = "edit";
  input.value = todos[i].text;
  input.maxLength = 300;
  span.replaceWith(input);
  input.focus();
  input.select();

  let selesai = false;
  const finish = async (simpan) => {
    if (selesai) return;
    selesai = true;
    const v = input.value.trim();
    if (simpan && v && v !== todos[i].text) {
      todos[i].text = v;
      await saveTodos();
    }
    render();
  };
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") finish(true);
    else if (e.key === "Escape") finish(false);
  });
  input.addEventListener("blur", () => finish(true));
}

function render() {
  const list = $("todo-list");
  list.textContent = "";
  todos.forEach((t, i) => {
    const li = document.createElement("li");
    if (t.done) li.className = "done";

    const check = document.createElement("input");
    check.type = "checkbox";
    check.checked = t.done;
    check.addEventListener("change", async () => {
      todos[i].done = check.checked;
      await saveTodos();
      render();
    });

    const text = document.createElement("span");
    text.textContent = t.text;
    text.addEventListener("dblclick", () => startEdit(li, i));

    const edit = document.createElement("button");
    edit.textContent = "✎";
    edit.title = "Ubah";
    edit.addEventListener("click", () => startEdit(li, i));

    const del = document.createElement("button");
    del.textContent = "×";
    del.title = "Hapus";
    del.addEventListener("click", async () => {
      todos.splice(i, 1);
      await saveTodos();
      render();
    });

    li.append(check, text, edit, del);
    list.append(li);
  });
}

$("todo-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const input = $("todo-input");
  const text = input.value.trim();
  if (!text) return;
  todos.push({ text, done: false });
  input.value = "";
  await saveTodos();
  render();
});

$("btn-clear-done").addEventListener("click", async () => {
  const sisa = todos.filter((t) => !t.done);
  const n = todos.length - sisa.length;
  if (!n) return msg("Belum ada tugas yang selesai.");
  todos = sisa;
  await saveTodos();
  render();
  msg(n + " tugas selesai dihapus.");
});

// ---------- Ekspor / impor ----------
$("btn-export").addEventListener("click", () => {
  const data = { app: "aistim-board", versi: 1, diekspor: new Date().toISOString(), todos };
  const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = "aistim-board-tugas.json";
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  msg("Diekspor: " + todos.length + " tugas.");
});

$("btn-import").addEventListener("click", () => $("file-import").click());

$("file-import").addEventListener("change", async (e) => {
  const file = e.target.files[0];
  e.target.value = "";
  if (!file) return;
  try {
    if (file.size > 2 * 1024 * 1024) throw new Error("Berkas terlalu besar.");
    const data = JSON.parse(await file.text());
    const arr = Array.isArray(data) ? data : data && data.todos;
    if (!Array.isArray(arr)) throw new Error("Format tidak dikenali.");
    const ada = new Set(todos.map((t) => t.text));
    let tambah = 0;
    arr.forEach((t) => {
      const text = t && typeof t.text === "string" ? t.text.trim().slice(0, 300) : "";
      if (!text || ada.has(text)) return;
      ada.add(text);
      todos.push({ text, done: !!t.done });
      tambah++;
    });
    await saveTodos();
    render();
    msg("Diimpor: " + tambah + " tugas baru (duplikat dilewati).");
  } catch (err) {
    msg("Gagal impor: " + err.message);
  }
});

// ---------- Pengaturan ----------
const dlg = $("dlg-settings");
let gambarBaru = null; // data URL gambar yang baru dipilih (belum disimpan)

GRADIENTS.forEach((g, i) => {
  const o = document.createElement("option");
  o.value = String(i);
  o.textContent = g.nama;
  $("set-grad").append(o);
});

function syncRows() {
  const mode = $("set-bg").value;
  $("row-warna").hidden = mode !== "warna";
  $("row-gambar").hidden = mode !== "gambar";
  $("row-online").hidden = mode !== "online";
}

function resizeImage(file, maxSide = 1920) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const k = Math.min(1, maxSide / Math.max(img.width, img.height));
      const c = document.createElement("canvas");
      c.width = Math.round(img.width * k);
      c.height = Math.round(img.height * k);
      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL("image/jpeg", 0.82));
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Gambar tidak bisa dibaca."));
    };
    img.src = url;
  });
}

// ---------- Tampilan buatan sendiri ----------
const BAWAAN = [["board", "Board"], ["start", "Aistim"], ["sync", "Aistim.sync"]];

let editing = null; // { kind: "sync" | "view", id }

const ICONS = {
  pakai: '<circle cx="12" cy="12" r="9"/><path d="M8 12.5l3 3 5-6"/>',
  edit: '<path d="M8 8l-4 4 4 4M16 8l4 4-4 4M14 5l-4 14"/>',
  nama: '<path d="M4 20h4L19 9l-4-4L4 16zM13 7l4 4"/>',
  hapus: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6"/>',
};

function btn(name, label, fn, danger) {
  const b = document.createElement("button");
  b.type = "button";
  b.className = "ico" + (danger ? " danger" : "");
  b.title = label;
  b.setAttribute("aria-label", label);
  b.innerHTML = '<svg viewBox="0 0 24 24">' + ICONS[name] + "</svg>";
  b.addEventListener("click", fn);
  return b;
}

// Popup kecil serbaguna: tanya teks (tambah/ubah nama) atau konfirmasi (hapus)
const dlgMenu = $("dlg-menu");
let menuAksi = null;
function popup({ judul, teks, nilai, ok, bahaya }) {
  return new Promise((resolve) => {
    $("menu-title").textContent = judul;
    $("menu-text").textContent = teks || "";
    $("menu-text").hidden = !teks;
    const inp = $("menu-input");
    inp.hidden = nilai === undefined;
    inp.value = nilai || "";
    $("menu-ok").textContent = ok || "OK";
    $("menu-ok").className = bahaya ? "danger" : "pri";
    menuAksi = (batal) => {
      dlgMenu.close();
      menuAksi = null;
      resolve(batal ? null : nilai === undefined ? true : inp.value.trim().slice(0, 30));
    };
    dlgMenu.showModal();
    if (nilai !== undefined) { inp.focus(); inp.select(); }
  });
}
$("menu-cancel").addEventListener("click", () => menuAksi && menuAksi(true));
dlgMenu.addEventListener("cancel", (e) => { e.preventDefault(); menuAksi && menuAksi(true); });
$("form-menu").addEventListener("submit", (e) => { e.preventDefault(); menuAksi && menuAksi(false); });

function renderViews(pilih) {
  const sel = $("set-view");
  sel.textContent = "";
  [...BAWAAN, ...views.map((v) => ["v:" + v.id, v.nama])].forEach(([val, label]) => {
    const o = document.createElement("option");
    o.value = val;
    o.textContent = label;
    sel.append(o);
  });
  sel.value = pilih;
  if (sel.value !== pilih) sel.value = "board";
  const aktif = sel.value;

  const tb = $("view-list");
  tb.textContent = "";
  const baris = [
    ...BAWAAN.map(([val, nama]) => ({ val, nama, jenis: "Bawaan", sync: val === "sync" })),
    ...views.map((v, i) => ({ val: "v:" + v.id, nama: v.nama, jenis: "Buatan", i, v })),
  ];
  baris.forEach((r, n) => {
    const tr = document.createElement("tr");
    if (r.val === aktif) tr.className = "aktif";
    const c0 = document.createElement("td");
    c0.textContent = r.val === aktif ? "✓" : String(n + 1);
    const c1 = document.createElement("td");
    c1.textContent = r.nama;
    const sm = document.createElement("small");
    sm.textContent = r.jenis;
    c1.append(sm);
    const c2 = document.createElement("td");
    c2.className = "aksi";
    c2.append(btn("pakai", "Pakai", () => renderViews(r.val)));
    if (r.sync) c2.append(btn("edit", "Edit HTML", () => openEditor({ kind: "sync" })));
    if (r.v) {
      c2.append(btn("edit", "Edit HTML", () => openEditor({ kind: "view", id: r.v.id })));
      c2.append(
        btn("nama", "Ubah nama", async () => {
          const baru = await popup({ judul: "Ubah nama menu", nilai: r.v.nama, ok: "Simpan" });
          if (!baru) return;
          views[r.i].nama = baru;
          await saveViews();
          renderViews($("set-view").value);
        })
      );
      c2.append(
        btn(
          "hapus",
          "Hapus",
          async () => {
            if (!(await popup({ judul: "Hapus menu", teks: 'Hapus menu "' + r.v.nama + '" beserta HTML-nya?', ok: "Hapus", bahaya: true }))) return;
            const dipilih = $("set-view").value === r.val;
            views.splice(r.i, 1);
            await saveViews();
            renderViews(dipilih ? "board" : $("set-view").value);
          },
          true
        )
      );
    }
    tr.append(c0, c1, c2);
    tb.append(tr);
  });
}

async function openEditor(target) {
  editing = target;
  let html = DEFAULT_VIEW_HTML;
  if (target.kind === "sync") {
    const pw = await store.get("syncPass", null);
    if (pw && pw.hash) return msg("Aistim.sync terkunci. Buka lewat Aistim.sync dengan password.");
    html = (await store.get("syncLocal", "")) || (await store.get("syncHtmlV", "")) || html;
    $("ed-title").textContent = "Edit HTML: Aistim.sync";
    $("ed-reset").hidden = !(await store.get("syncLocal", ""));
  } else {
    const v = views.find((x) => x.id === target.id);
    if (!v) return;
    html = v.html || html;
    $("ed-title").textContent = "Edit HTML: " + v.nama;
    $("ed-reset").hidden = true;
  }
  $("ed-text").value = html;
  $("ed-msg").textContent = "";
  $("menu-table").hidden = true;
  $("menu-editor").hidden = false;
  $("btn-cancel").closest("menu").hidden = true; // sembunyikan Batal/Simpan utama saat mengedit HTML
  $("ed-text").focus();
}

function closeEditor() {
  editing = null;
  $("btn-cancel").closest("menu").hidden = false;
  $("menu-editor").hidden = true;
  $("menu-table").hidden = false;
}

$("ed-cancel").addEventListener("click", closeEditor);
$("ed-save").addEventListener("click", async () => {
  const v = $("ed-text").value;
  if (!v.trim() || v.length > 500000) return ($("ed-msg").textContent = "Isi kosong atau terlalu besar.");
  if (editing.kind === "sync") await store.set("syncLocal", v);
  else {
    const e = views.find((x) => x.id === editing.id);
    if (e) e.html = v;
    await saveViews();
  }
  closeEditor();
  msg("HTML disimpan.");
});
$("ed-reset").addEventListener("click", async () => {
  if (hasChrome) await chrome.storage.local.remove("syncLocal");
  else localStorage.removeItem("syncLocal");
  closeEditor();
  msg("Dikembalikan ke versi GitHub.");
});

$("btn-add-view").addEventListener("click", async () => {
  if (views.length >= 20) return msg("Maksimal 20 menu.");
  const nama = await popup({ judul: "Tambah menu", nilai: "", ok: "Tambah" });
  if (!nama) return;
  const id = Date.now().toString(36);
  views.push({ id, nama, html: DEFAULT_VIEW_HTML });
  await saveViews();
  renderViews("v:" + id);
});

try {
  if (hasChrome && chrome.runtime && chrome.runtime.getManifest) $("ver").textContent = "v" + chrome.runtime.getManifest().version;
} catch (e) {}

function showTab(n) {
  document.querySelectorAll(".tab").forEach((t) => {
    const on = t.dataset.tab === String(n);
    t.classList.toggle("active", on);
    t.setAttribute("aria-selected", on);
  });
  document.querySelectorAll(".tab-panel").forEach((p) => (p.hidden = p.id !== "tab-" + n));
}
document.querySelectorAll(".tab").forEach((t) => t.addEventListener("click", () => showTab(t.dataset.tab)));

$("btn-settings").addEventListener("click", () => {
  gambarBaru = null;
  showTab(1);
  closeEditor();
  renderViews(settings.tampilan || "board");
  $("set-name").value = settings.nama || "";
  $("set-24h").checked = !!settings.jam24;
  $("set-bg").value = settings.latar;
  $("set-grad").value = String(settings.warna);
  $("set-foto").value = ["tab", "jam", "hari"].includes(settings.foto) ? settings.foto : "hari";
  $("set-img").value = "";
  $("img-info").textContent = settings.gambar ? "Gambar tersimpan. Pilih berkas baru untuk menggantinya." : "Belum ada gambar.";
  syncRows();
  dlg.showModal();
});
$("set-bg").addEventListener("change", syncRows);
$("btn-cancel").addEventListener("click", () => dlg.close());

$("set-img").addEventListener("change", async (e) => {
  const f = e.target.files[0];
  if (!f) return;
  try {
    gambarBaru = await resizeImage(f);
    $("img-info").textContent = "Gambar siap disimpan (" + Math.round(gambarBaru.length / 1024) + " KB).";
  } catch (err) {
    gambarBaru = null;
    $("img-info").textContent = err.message;
  }
});

$("form-settings").addEventListener("submit", async () => {
  const latar = $("set-bg").value;
  const gambar = gambarBaru || settings.gambar;
  settings = {
    nama: $("set-name").value.trim().slice(0, 30),
    jam24: $("set-24h").checked,
    latar: latar === "gambar" && !gambar ? "harian" : latar, // tanpa gambar tersimpan, kembali ke latar harian
    warna: Number($("set-grad").value) || 0,
    gambar,
    foto: $("set-foto").value,
    tampilan: $("set-view").value,
  };
  try {
    await store.set("settings", settings);
  } catch (e) {
    // gambar terlalu besar untuk disimpan: lepas gambarnya, sisanya tetap disimpan
    settings.gambar = "";
    if (settings.latar === "gambar") settings.latar = "harian";
    await store.set("settings", settings);
  }
  if (settings.tampilan === "start") return showStart();
  if (settings.tampilan === "sync") return showStart("menu/sync.html");
  if (String(settings.tampilan).startsWith("v:")) return openCustom();
  applyBackground();
  tick();
});


async function startBoard() {
  tick();
  setInterval(tick, 1000);
  initQuote();
  applyBackground();
  todos = await store.get("todos", []);
  render();
}

function showError(e) {
  const d = document.createElement("div");
  d.textContent = "Gagal memuat sebagian: " + (e && e.message ? e.message : e);
  d.style.cssText = "position:fixed;left:12px;right:12px;bottom:12px;padding:10px 12px;border-radius:8px;background:#7f1d1d;color:#fff;font:13px system-ui;z-index:99";
  document.body.append(d);
}

(async function init() {
  tick(); // jam langsung tampil, tidak menunggu penyimpanan
  try {
    const s = await store.get("settings", {});
    settings = { ...DEFAULT_SETTINGS, ...(s && typeof s === "object" ? s : {}) };
    const v = await store.get("views", []);
    views = Array.isArray(v) ? v : [];
    if (!views.length) {
      try {
        const b = JSON.parse(localStorage.getItem("views-backup") || "[]");
        if (Array.isArray(b) && b.length) { views = b; await store.set("views", views); }
      } catch (e) {}
    }
    const t = String(settings.tampilan);
    if (t === "start") return showStart();
    if (t === "sync") return showStart("menu/sync.html");
    if (t.startsWith("v:")) {
      if (views.some((x) => x.id === t.slice(2))) return openCustom();
      settings.tampilan = "board"; // menu sudah dihapus: kembali ke Board
      store.set("settings", settings);
    }
  } catch (e) {
    showError(e);
  }
  try {
    await startBoard();
  } catch (e) {
    showError(e);
  }
})();
